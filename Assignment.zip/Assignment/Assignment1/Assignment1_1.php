<html>
    <Head>
        <title>Chess Board</title>
    </Head>
    <body>
        <table width="400px" border="1px" cellspacing="0px">
            <?php 
            $count = 0;
            for($i = 0; $i < 8; $i++){
                echo "<tr>";
                $count = $i;
                for($j=0; $j<8; $j++){
                    if($count%2 == 0){
                        echo "<td height=40px width=20px bgcolor=black></td>";
                        $count++;
                    }else {
                        echo "<td height=40px width=20px bgcolor=white></td>";
                        $count++;
                    }
                }
                echo "</tr>";
            }
            ?>
        </table>
    </body>
</html>
