<html>
    <head>
        <title>calculator</title>
    </head>
    <body>
    <?php
    	$fnum = $_POST['fnum'];
        $snum = $_POST['snum'];
        $operator = $_POST['operator'];
        $result = "";
        $error = "";
        
        if(is_numeric($fnum) && is_numeric($snum)){
            switch($operator){
                case "ADD":
                    $result = $fnum + $snum;
                    break;

                case "SUB":
                    $result = $fnum - $snum;
                    break;

                case "DIV":
                    $result = $fnum / $snum;
                    break;
                    
                case "MUL":
                    $result = $fnum * $snum;
                    break;
            }
        }
        else {
            $error = "Enter only number";
        }
    ?>
        <h1>
            Simple Calculator
        </h1>
        <form method="POSt">
            <label>
                Enter First Number: 
            </label> &nbsp;
            <input type="text" name="fnum" id="fnum" value="<?php echo $fnum; ?>" />
            <br></br>
            <label>
                Enter Second Number: 
            </label> &nbsp;
            <input type="text" name="snum" id="snum" value="<?php echo $snum; ?>" />
            <br></br>
            <label>
                Operators: 
            </label> &nbsp;
            <input type="submit" name="operator" value="ADD" />
            <input type="submit" name="operator" value="SUB" />
            <input type="submit" name="operator" value="DIV" />
            <input type="submit" name="operator" value="MUL" />
            <br></br>
            <label>
                Result: 
            </label> &nbsp;
            <input readonly="readonly" type="text" name="Result" id="Result" value="<?php echo $result; ?>" />
            <br>
            <input readonly="readonly" type="text" name="error" id="error" value="<?php echo $error; ?>" />
        </form>
    </body>
</html>