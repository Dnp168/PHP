<html>
    <head>
        <title>Voting</title>
    </head>
    <body>
    <?php
    	
        if (isset($_POST['submit'])) {
            $age = $_POST['age'];
            if(is_numeric($age)){
                if($age>18){
                 $result= "You are valid for voting";
                } else {
                 $result= "You are not valid for voting";
                }
             }
             else {
                 $error = "Enter only number";
             }
        }
        
    ?>
        <form method="POSt">
            <label>
                Enter Your Age: 
            </label> &nbsp;
            <input type="text" name="age" id="age" value="<?php echo $age; ?>" />&nbsp;
            <input type = "submit" name = "submit" value = "Submit">
            <br>
            <input readonly="readonly" type="text" name="Result" id="Result" value="<?php echo $result; ?>" />
        </form>
    </body>
</html>