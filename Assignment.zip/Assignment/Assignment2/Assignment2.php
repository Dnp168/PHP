<html>
<body>

<?php

// strtolower() function 
echo strtolower("Hello WORLD.");

// explode()
$str = 'one,two,three,four';

// zero limit
print_r(explode(',',$str,0));
print "<br>";

// positive limit
print_r(explode(',',$str,2));
print "<br>";

// negative limit 
print_r(explode(',',$str,-1));

// strpos()
echo strpos("I love php","php");

// ucfirst()
echo ucfirst("hello world!");

//substr()
echo substr("Hello world",6);

//array_merge()
$a1=array("red","green");
$a2=array("blue","yellow");
print_r(array_merge($a1,$a2));

//array_rand()
$a=array("red","green","blue","yellow","brown");
$random_keys=array_rand($a,3);
echo $a[$random_keys[0]]."<br>";
echo $a[$random_keys[1]]."<br>";
echo $a[$random_keys[2]];

//array_slice()
$a=array("red","green","blue","yellow","brown");
print_r(array_slice($a,1,2,true));


$a=array("red","green","blue","yellow","brown");
print_r(array_slice($a,1,2,false));

//array_merge_recursive()
$a1=array("a"=>"red","b"=>"green");
$a2=array("c"=>"blue","b"=>"yellow");
print_r(array_merge_recursive($a1,$a2));

//array_reverse()
$a=array("a"=>"Volvo","b"=>"BMW","c"=>"Toyota");
print_r(array_reverse($a));

?>
 
</body>
</html>